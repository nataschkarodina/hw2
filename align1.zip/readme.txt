File(s) successfully added :
	ENSG00000115607_IL18RAP_000_raw_NT.fasta
File(s) with errors :
